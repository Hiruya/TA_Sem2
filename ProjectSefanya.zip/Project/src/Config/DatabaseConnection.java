package Config;

import java.util.logging.Logger;
import java.util.logging.Level;
import java.sql.Connection;
import java.sql.DriverManager;

public class DatabaseConnection {

    private static Connection conn;

    public static Connection getConnection() {
        if (conn == null) {
            try {
                String SUrl, SUser, SPass;
                SUrl = "jdbc:mysql://localhost:3306/db_sistem_transaksi";
                SUser = "root";
                SPass = "";
                DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
                conn = (Connection) DriverManager.getConnection(SUrl, SUser, SPass);
            } catch (Exception e) {
                Logger.getLogger(DatabaseConnection.class.getName()).log(Level.SEVERE, null, e);
            }
        }
        return conn;
    }
}